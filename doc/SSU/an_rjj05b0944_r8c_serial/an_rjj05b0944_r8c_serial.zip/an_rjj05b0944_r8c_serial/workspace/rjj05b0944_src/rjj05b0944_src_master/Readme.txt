-------- PROJECT GENERATOR --------
PROJECT NAME :	rjj05b0944_src_master
PROJECT DIRECTORY :	C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master
CPU SERIES :	R8C/Tiny
CPU GROUP :	2D
TOOLCHAIN NAME :	Renesas M16C Standard Toolchain
TOOLCHAIN VERSION :	5.45.01
GENERATION FILES :
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\typedefine.h
        define scalar types.
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\resetprg.c
        initialize for C language.
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\resetprg.h
        include some headder files.
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\initsct.c
        initialize each sections.
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\initsct.h
        define the macro for initialization of sections.
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\fvector.c
        define the fixed vector table.
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\intprg.c
        define the top address of the interrupt vectors.
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\sfr_r82d.h
        define the sfr register. (for C language)
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\sfr_r82d.inc
        define the sfr register. (for Assembler language)
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\heap.c
        define the size of heap.
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\rjj05b0944_src_master.c
        main program file.
    C:\WorkSpace\rjj05b0944_src\rjj05b0944_src_master\cstartdef.h
        define the size of stack.

SELECT TARGET :
    M16C R8C Simulator
    R8C E8a SYSTEM
DATE & TIME : 2011/01/07 15:41:02
